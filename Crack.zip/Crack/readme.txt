00. Before installation, block the outgoing Internet access by means of Windows 
   Firewall or cord plug. Check .NET Framework 3.5 and 4.0 are installed. If
   .NET Framework 3.5 (including 2.0) is not installed, go to 
   "Control Panel" -> "Programs and Features" -> "Turn Windows features on or off" ->
   -> select ".NET Framework 3.5 (including 2.0)"

000. Uninstall (if exist) SolidWorks_Flexnet_Server from SW2020 SSQ's release!
    To do it run as Administrator SolidWorks_Flexnet_Server\server_remove.bat 
    and wait until service "SolidWorks Flexnet Server" will be removed
    After that delete SolidWorks_Flexnet_Server folder from computer 

1. Run "sw2023_network_serials_licensing.reg" and confirm to add info 
   into Windows Registry

2. Copy folder "SolidWorks_Flexnet_Server" to C: , run as Administrator
   "SolidWorks_Flexnet_Server\server_install.bat" and wait until new service 
   "SolidWorks Flexnet Server" will be install and started

3. Install SolidWorks 2023 (including PDM Client if required). 
   DO NOT install SolidNetwork License Server (SNL)!
   When asked of License Server definition input: 25734@localhost

   3.1 If the System Check Warning window appears, ignore it (click Next to continue)

   3.2 If the warning "SolidWorks Serial number was not found in activation database" 
       appears, ignore it (click OK to continue)

   3.3 If the full list of SW products to install is not visible,
       click "Select different package" and tick option 
       "Select products not included in this package"

   3.4 Select SW products to be installed

   3.5 If the "The Installation Manager was unable to determine the current subscription 
       expiration date. Would you like to reactivate your license to update this information?"
       appears, press No and press Yes in "Do you want to do it later?" prompt.

4. After end of setup overwrite original SolidWorks 2020 program folders (if exist)
   with cracked ones from folder "Program Files\SOLIDWORKS Corp" and "Program Files (x86)"

   Folders to be replaced from "Program Files\SOLIDWORKS Corp" (at setup by default):

   C:\Program Files\SOLIDWORKS Corp\eDrawings  
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS CAM
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Composer
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Electrical
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Explorer
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Flow Simulation
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Inspection
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Manage Client
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS PCB
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS PDM
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Plastics
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Visualize
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Visualize Boost

   Folders to be replaced from "Program Files (x86)" (at setup by default):

   C:\Program Files (x86)\SOLIDWORKS PDM


5. Run "SolidSQUADLoaderEnabler.reg" and confirm to add info 
   into Windows Registry

6. REBOOT COMPUTER!

7. Run SolidWorks > Help > SolidNetWork License Manager > License Order

   Use the "Move Up" and "Move Down" buttons to position Premium products with 
   the same name higher than Professional and Standard products

   Click "Apply" to save the settings

   Click "OK" to close the SolidNetWork License Manager

8. Enjoy


NOTE:

   Since SW2019 network licensing crack uses other serial numbers than the previous (SW2010-2018)
   versions then if you installed SW2021 on one same computer with SW2010-2018 you need to:
 
   For SW2017-2018 reactivate them by running the corresponding SSQ's SW2017-2018 Activator (run 
   SSQ's SW2017-2018 Activator, select proper SW version and click "Activate Licenses")

   For SW2010-2016 replace original SolidWorks 2010-2016 program folders (if exist)
   with cracked ones from folder "Program Files\SOLIDWORKS Corp" and "Program Files (x86)"

   Folders to be replaced from "Program Files\SOLIDWORKS Corp" (at setup by default):

   C:\Program Files\SOLIDWORKS Corp\eDrawings  
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS CAM
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Composer
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Electrical
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Explorer
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Flow Simulation
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Inspection
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Manage Client
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS PCB
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS PDM
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Plastics
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Visualize
   C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS Visualize Boost

   Folders to be replaced from "Program Files (x86)" (at setup by default):

   C:\Program Files (x86)\SOLIDWORKS PDM



